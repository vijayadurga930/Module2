import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-sortnamestudent',
  templateUrl: './sortnamestudent.component.html',
  styleUrls: ['./sortnamestudent.component.css']
})
export class SortnamestudentComponent implements OnInit {
  students:IStudent[];
  constructor(private studentService: StudentService) {
    this.students=this.studentService.getData();
   }

  ngOnInit() {
  }

  sortName(students){
    this.studentService.sortByName(students);
  }

}
