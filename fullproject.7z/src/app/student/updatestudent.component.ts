import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { ActivatedRoute } from '@angular/router';
import { IStudent } from './student.interface';
import { StudentlistComponent } from './studentlist.component';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdatestudentComponent implements OnInit {
  students:IStudent[];
  student:IStudent;
  constructor(private studentService:StudentService) { 
    this.students=studentService.getData();
  }

  ngOnInit() {
    console.log(this.student.id);
    this.students=this.students.filter(s=>s.id==this.student.id);
  }
  updateStudent(student:IStudent){
    console.log(student);
  }
}
