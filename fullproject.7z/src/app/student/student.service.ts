import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IStudent } from './student.interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  students:IStudent[];

  constructor(private http:HttpClient) {
    this.getStudents().subscribe(data=>this.students=data);
   }

  getStudents():Observable<IStudent[]>{
    return this.http.get<IStudent[]>("../../assets/students.json");
  }

  getData(){
    return this.students;
  }

  addStudent(student:IStudent){
    return this.students.push(student);
  }

  setStudent(students:IStudent[]){
    this.students=students;
  }

  deleteStudent(id:number){
    this.students=this.students.filter(s=>s.id!=id);
  }

  sortById(){
    return this.students.sort((a, b) => a['id'] > b['id'] ? 1 : a['id'] === b['id'] ? 0 : -1);
  }

  sortByName(students:IStudent[]) {
 
    console.log(this.sortByName);
    return students.sort((a, b) => a['name'] > b['name'] ? 1 : a['name'] === b['name'] ? 0 : -1);
    
    }
    // updateStudent(student:IStudent){

    //   return this.students.
    // }
}
