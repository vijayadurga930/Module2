import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { IStudent } from './student.interface';

@Component({
  selector: 'app-sortstudent',
  templateUrl: './sortstudent.component.html',
  styleUrls: ['./sortstudent.component.css']
})
export class SortstudentComponent implements OnInit {
  students:IStudent[];
 
  constructor(private studentsService: StudentService) { 
    this.students=this.studentsService.getData();
  }

  ngOnInit() {
  }
  

  Sort(){
    this.studentsService.sortById();
  }
}
