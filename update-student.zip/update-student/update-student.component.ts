import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentService } from 'src/app/student.service';
import { Student } from '../student.interface';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit {
  studentData:Student={"id":0,"name":'',"age":0,"gender":'',"phone":0};
  constructor(private studentService:StudentService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
  }
  
  update(){
    console.log(this.studentData.name);
    this.studentService.updateStudent(this.studentData).subscribe((data)=>{this.router.navigate(['students']);})
  }

}
