export interface IStudent {
    id:number;
    name:string;
    gender:string;
    age:number;
    mobile:string;
    
  
  
  }