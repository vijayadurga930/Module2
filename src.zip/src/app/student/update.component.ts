import { Component, OnInit } from '@angular/core';
import { IStudent } from './student.interface';
import { StudentService } from './student.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
students:IStudent[];
  constructor(private studentService:StudentService) { }

  ngOnInit() {
  }
  update(id:number){
    console.log(id);
    this.studentService.updateStudent(id);
  }

}
