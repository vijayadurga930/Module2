import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentlistComponent } from './student/studentlist.component';
import { AddstudentComponent } from './student/addstudent.component';
import { StartPageComponent } from './student/start-page.component';
import { SearchStudentComponent } from './student/search-student.component';


const routes: Routes = [
  {path:"students",component:StudentlistComponent},
  {path:"add",component:AddstudentComponent},
  {path:"search", component:SearchStudentComponent},
  {path:'',component:StartPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
