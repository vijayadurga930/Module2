import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatecustomercls',
  templateUrl: './updatecustomercls.component.html',
  styleUrls: ['./updatecustomercls.component.css']
})
export class UpdatecustomerclsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
