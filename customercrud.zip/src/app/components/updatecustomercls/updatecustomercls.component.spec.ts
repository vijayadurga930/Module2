import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatecustomerclsComponent } from './updatecustomercls.component';

describe('UpdatecustomerclsComponent', () => {
  let component: UpdatecustomerclsComponent;
  let fixture: ComponentFixture<UpdatecustomerclsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatecustomerclsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatecustomerclsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
