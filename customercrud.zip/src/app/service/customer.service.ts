import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../model/customer';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  getSearchedData(): Customer[] {
    throw new Error("Method not implemented.");
  }
  setSearchedData(searchedData: Customer[]) {
    throw new Error("Method not implemented.");
  }
url:string="http://localhost:3000/customers";
  constructor(private http:HttpClient) { }
    addCustomer(customer:Customer){
      return this.http.post(this.url,customer);
    }
    getAllCustomers(){
      return this.http.get<Customer[]>("../../assets/employee.json");
    }
    deleteCustomer(customer:Customer){
   return this.http.delete<Customer[]>(this.url+"/"+customer.id);
    }
    getCustomer(id:number){
      return this.http.get<Customer>("../../assets/employee.json");;
       }
       Updatecustomer(customer:Customer){
         return this.http.put(this.url+"/"+customer.id,customer);
       }
   }




