import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-showsearchdata',
  templateUrl: './showsearchdata.component.html',
  styleUrls: ['./showsearchdata.component.css']
})
export class ShowsearchdataComponent implements OnInit {
  searchedData: Customer[];
  constructor(private service:CustomerService) { }

  ngOnInit() {
    this.searchedData = this.service.getSearchedData();
  }

}
